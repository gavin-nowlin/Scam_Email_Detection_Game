# Scam Email Detector v1.0
Developed by:
- Sebastian Aguilar
- Daniel Dewar
- Emily Herman
- Preston Millhouse
- Gavin Nowlin
## Running Instructions
Just double click the .exe file **Scam Email Detector** and play!
Make sure you keep everything in the same directory after you extract the project and you are running x86-64.